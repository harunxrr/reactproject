import React from "react";

function ContactPage() {
  return (
    <>
      <div className="MainLoginBlog mt-5 col-10 col-lg-10 mx-auto">
        <h3 className="text-center my-5 opacity-75 ">İletişim</h3>

        <div className="GoogleMapsAddr row">
          <div className="col-12 col-lg-8">
            <iframe
              style={{ width: "100%" }}
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d770815.1869053458!2d28.35278722508894!3d41.00344271660253!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14caa7040068086b%3A0xe1ccfe98bc01b0d0!2zxLBzdGFuYnVs!5e0!3m2!1str!2str!4v1691251584150!5m2!1str!2str"
              width="600"
              height="450"
            ></iframe>
          </div>

          <div className="col-12 col-lg-4 p-lg-5 p-1 mt-3 mt-lg-0">
            <div className="d-flex justify-content-between  mb-3">
              <i className="fa fa-location-dot text-success fs-5"></i>
              <div className="ms-3">
                <h4>Adres</h4>
                <p>
                  Muallimköy Mh. Deniz Cd. Muallimköy T.G.B. 1. Etap Sitesi
                  1.1.C1 Blok No: 143/8 İç Kapı No: Z01, Bilişim Vadisi, 41400,
                  Gebze / Kocaeli
                </p>
              </div>
            </div>

            <div className="d-flex  mb-3">
              <i className="fa fa-phone fs-5 text-success"></i>
              <div className="ms-2 w-100">
                <h4>Telefon</h4>
                <p>
                  {" "}
                  <a href="#" className="nav-link">
                    0212 448 56 52
                  </a>
                </p>
              </div>
            </div>

            <div className="d-flex  mb-3">
              <i className="fa fa-envelope text-success  fs-5"></i>
              <div className="ms-2">
                <h4>E-mail</h4>
                <p className="">
                  <a href="#" className="nav-link">
                    info@gmail.com
                  </a>
                </p>
              </div>
            </div>
          </div>

          <div className="my-5">
            <h2 className="opacity-75 text-center">Bize Ulaşın</h2>
            <p className="text-center fw-bold text-secondary ">
              Aklınıza takılan her türlü konu ve sorularınız için bize aşağıdaki
              formu doldurarak ulaşabilirsiniz. İlgili ekibimiz sizinle en kısa
              sürede iletişime geçecektir.
            </p>
            <div className="col-12">
              <form>
                <div className="col-12 col-lg-8 mx-auto ">
                  <input
                    type="text"
                    placeholder="Adınız ve Soyadınız *"
                    className="form-control"
                  />
                </div>

                <div className="col-12 col-lg-8 mt-4 mx-auto">
                  <input
                    type="email"
                    placeholder="E-Posta adresiniz *"
                    className="form-control"
                  />
                </div>
                <div className="col-12 col-lg-8 mx-auto">
                  <textarea
                    style={{ minHeight: "300px" }}
                    className="form-control mt-4"
                    placeholder="Mesajınız..."
                  ></textarea>
                </div>
                <div className="d-flex justify-content-center mt-4 ">
                  <button
                    type="button"
                    className="btn btn-success rounded-5 px-4 mx-auto d-inline-block py-2 "
                  >
                    Gönder
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ContactPage;
